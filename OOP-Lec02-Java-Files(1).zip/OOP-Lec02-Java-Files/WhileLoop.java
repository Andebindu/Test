/*
 * Demonstration of While Loop Statement
 *
 */


/**
 *
 * @author U0018369
 */
					
							
public class WhileLoop {

    public static void main(String[] args) {

        int count = 1 ;

		while (count <= 5)
		{
			System.out.println("count is " + count); 
			count++;
		}

		System.out.println("finished looping, count is " + count);

    } 
}

