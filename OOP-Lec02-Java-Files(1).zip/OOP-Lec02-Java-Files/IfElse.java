/*
 * Demonstration of If Else Statement
 *
 */


/**
 *
 * @author U0018369
 */

// include scanner library (class) 
// that is required for processing keyboard inputs
import java.util.Scanner;					
							
public class IfElse {

    public static void main(String[] args) {

        // Creating a Scanner class object variable named keyboard 
        // which is connecting to process input typed in by user
        Scanner keyboard = new Scanner(System.in);		
        
        
        // Prompt user for input (note use of print instead of println)
        System.out.print("Please product name: ");
        
        // Read line of text and store in name
        String name = keyboard.nextLine();			
        
        
        //prompt for item price
        System.out.print("Enter item price (e.g. 1.25): ");
        
        // Read number with decimal place (double)
        double itemPrice = keyboard.nextDouble();
        
        
        // Read and discard Enter key pressed after above input
        keyboard.nextLine();				
	
        //prompt for quantity
        System.out.print("Enter quantity (e.g. 10): ");	

        // Read whole number (int) from keyboard
        int qty = keyboard.nextInt();				 
        keyboard.nextLine();				


        // Calculate the total cost
        double totalCost = itemPrice * qty;			

		//determine discount
		double discount = 0;
		if (qty > 10)
		{
			discount = 0.10;  // 10%
		}

		//appy discount
		totalCost = totalCost - (totalCost * discount);

        //Output name
        System.out.print("Product Name: ");
        System.out.println(name);

        // Output total cost
        // usinf printf so to format total cost to 2 decimal places
        System.out.printf("Total Cost: %.2f", totalCost);	 
        System.out.println();


		//ask if user is trade or not
        System.out.print("Trade customer (Y/N)? ");
		String tradeCustomer = keyboard.nextLine();
		
		//set how many days to pay cost
		int paymentPeriod;
		
		//determine how many days to pay cost based on user input
		if (tradeCustomer.equalsIgnoreCase("Y"))
		{						   
			//trade get longer time to pay
			paymentPeriod = 30;
		}
		else 
		{
			//non trade gets a week to pay
			paymentPeriod = 7;
		}
		
		//inform user
		System.out.println("Payment Period: " + paymentPeriod);

    } 
}

