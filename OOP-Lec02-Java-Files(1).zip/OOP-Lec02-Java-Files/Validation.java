/*
 * Demonstration of If Statement and While Loop statement tp provide validation
 *
 */


/**
 *
 * @author U0018369
 */

//load scanner class
import java.util.Scanner;					
							
public class Validation {

    public static void main(String[] args) {

		//creaye scanner object
		Scanner myInput = new Scanner(System.in);

		//prompt for age
		System.out.print("Please enter age: ");

		//get input
		int age = myInput.nextInt();

		//until user is 18 keep asking age
		while (age < 18)
		{
			System.out.print("Age must be 18 or over, please re-enter: ");
			age = myInput.nextInt();
		}

		//confirm user is old enough
		System.out.println("\nCongratulations you are now eligibe to vote.\n");
    } 
}

