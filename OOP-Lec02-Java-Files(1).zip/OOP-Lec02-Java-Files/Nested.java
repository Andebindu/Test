/*
 * Demonstration of Nested for Loops
 *
 */


/**
 *
 * @author U0018369
 */
					
							
public class Nested {

    public static void main(String[] args) {

		int outerCounter = 0;
		int innerCounter = 0;
		
		//start outer while loop
		while (outerCounter < 5)
		{	
			System.out.println("Outer Iteration " + outerCounter);
			
			//start the nested loop, i.e. inner while loop			
			while (innerCounter  < 3)
			{					
				System.out.println("\tInner loop, iteration " + innerCounter);
				innerCounter++;

			} // end of nested while loop
				
			// Reset innerCounter for next iteration of outer loop
			innerCounter = 0;
			
			//increment outer counter
			outerCounter++;
		
		} // end of outer while loop

    } 
}

