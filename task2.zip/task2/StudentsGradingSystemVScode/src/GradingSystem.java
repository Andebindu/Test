import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.File;


public class GradingSystem {
    public static void main(String[] args) throws Exception {
        Scanner dataInput = new Scanner(System.in);
        String csvFile = "/Users/mac/Library/CloudStorage/OneDrive-TeessideUniversity/ica/oop/task2/StudentsGradingSystemVScode/src/student-results.csv";
    
        File file = new File(csvFile);
        if(file.length() == 0){
            System.out.println("File is empty, would you like to delete?");
            System.out.println("Yes: y");
            System.out.println("No: n");
            String choice = dataInput.nextLine();
            switch (choice) {
                case "y":
                case "Y":
                    deleteFile(csvFile);
                    break;
                case "N":
                case "n":
                    break;
                default:
                    System.out.println("Invalid choice. Exiting.");
            }
        }else{
            List<Students> students = readFile(csvFile);

            List<String> moduleStatisticsList = calculateModuleStatistics(students);

            //set longest fullname as name's column width
            int nameWidth = 0;
            for (Students student : students) {
                int fullNameLength = getStudentFullName(student.getStudentFirstName(),student.getStudentLastName()).length();
                if (fullNameLength > nameWidth) {
                    nameWidth = fullNameLength;
                }
            }

            System.out.println();
            System.out.println();
            System.out.println("-------------------");
            System.out.println("Student Grades");
            System.out.println("-------------------");

            //print out all students and respective modules
            for (Students student : students) {
                System.out.printf("%-" + (nameWidth+5) + "s",getStudentFullName(student.getStudentFirstName(),student.getStudentLastName()));
                List<Modules> modules = student.getStudentModules();
                for (Modules module : modules) {
                    System.out.print(module.getModuleCode()+": ");
                    System.out.print(module.studentGrade+" ");
                }
                System.out.println();
            }

            System.out.println();
            System.out.println("-------------------");
            System.out.println("Module Statistics");
            System.out.println("-------------------");
            displayModuleStatistics(moduleStatisticsList);

            System.out.println("What would you like to do next ?");
            System.out.println("Empty File: 1");
            System.out.println("Delete File: 2");
            System.out.println("Quite: 3");

            int choice = dataInput.nextInt();
            switch (choice) {
                case 1:
                    emptyFile(csvFile);
                    break;
                case 2:
                    deleteFile(csvFile);
                    break;
                case 3:
                    writeModuleStatisticsCSV(moduleStatisticsList, "/Users/mac/Library/CloudStorage/OneDrive-TeessideUniversity/ica/oop/task2/StudentsGradingSystemVScode/src/module-statistics.csv");
                    break;
                default:
                    System.out.println("Invalid choice. Exiting.");
            }
        }
    }

    private static List<Students> readFile(String csvFile) {
        List<Students> students = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                students.add(parseStudent(data));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return students;
    }

    private static Students parseStudent(String[] data) {
        String studentId = data[0];
        String firstName = data[1];
        String lastName = data[2];

        Students student = new Students();
        student.setStudentID(studentId);
        student.setStudentFirstName(firstName);
        student.setStudentLastName(lastName);

        for (int i = 3; i < data.length; i += 2) {
            String moduleCode = data[i];
            int mark = Integer.parseInt(data[i + 1]);
            Modules module = new Modules();
            module.setModuleCode(moduleCode);
            module.mark = mark;
            module.studentGrade = gradeConverter(mark);
            student.setModule(module);
        }
        return student;
    }

    private static void displayModuleStatistics(List<String> moduleStatisticsList) {
        // Display module statistics
        System.out.println("Module,Highest Mark,Lowest Mark,Average Mark,Passes,Fails");
        for (String moduleStatistics : moduleStatisticsList) {
            System.out.println(moduleStatistics);
        }
        
    }

    private static void emptyFile(String filePath){
        try{
           PrintWriter writer = new PrintWriter(new File(filePath));
           writer.write("");
           System.out.println("File " + filePath + " has been emptied.");
            
        }catch(FileNotFoundException e){
            e.printStackTrace();
            System.err.println("Error: File not found.");
        }catch(Exception e){
            System.err.println("Something went wrong");
        }
    }

    private static void deleteFile(String filePath) {
        try{
            Path path = Paths.get(filePath);
            Files.delete(path);
            System.out.println("File " + filePath + " has been deleted.");
         }catch(FileNotFoundException e){
             e.printStackTrace();
             System.err.println("Error: File not found.");
         }catch(Exception e){
             System.err.println("Something went wrong");
         }
    }


    private static List<String> calculateModuleStatistics(List<Students> students) {
        List<String> moduleStatisticsList = new ArrayList<>();

        // Iterate over modules
        for (int i = 0; i < students.get(0).getStudentModules().size(); i++) {
            String moduleCode = students.get(0).getStudentModules().get(i).getModuleCode();
            List<Integer> moduleMarks = new ArrayList<>();

            // Collect marks for the current module
            for (Students student : students) {
                int mark = student.getStudentModules().get(i).mark;
                moduleMarks.add(mark);
            }

            // Calculate module statistics within the Module class
            Modules module = new Modules();
            module.moduleCode = moduleCode;
            module.moduleMarks = moduleMarks;
            String moduleStatistics = module.calculateStatistics();

            moduleStatisticsList.add(moduleStatistics);
        }

        return moduleStatisticsList;
    }

    private static void writeModuleStatisticsCSV(List<String> moduleStatisticsList, String csvFile) {
        try (PrintWriter writer = new PrintWriter(new File(csvFile))) {
            writer.println("Module,Highest Mark,Lowest Mark,Average Mark,Passes,Fails");

            for (String moduleStatistics : moduleStatisticsList) {
                writer.println(moduleStatistics);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //getter for student's full name
    public static String getStudentFullName(String studentFirstName, String studentLastName){
        return studentFirstName+", "+shortenLastName(studentLastName)+".";
    }

    //return only first element in last name as initials
    public static char shortenLastName(String lastName){
        if (lastName != null && lastName.length() > 0) {
            return lastName.charAt(0);
        } else {
            return ' ';
        }
    }

    //method validate mark inputs
    public static int tryMarkAdding(Scanner dataInput) {
        int studentMark;
        while (true) {
            try {
                studentMark = Integer.parseInt(dataInput.nextLine());
                if (studentMark >= 0 && studentMark <= 100) {
                    break;
                } else {
                    System.out.println("Invalid mark. Please enter a mark between 0 and 100.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid mark.");
            }
        }
        return studentMark;
    }

    //setter for student's mark and grade per module
    public static String setStudentMarkGrade(int studentMarks, Scanner dataInput){
        while (studentMarks < 0 || studentMarks > 100) {
            System.out.println("Invalid mark. Please enter a mark between 0 and 100.");
            studentMarks = tryMarkAdding(dataInput);
        }

        return gradeConverter(studentMarks);
    }

    //method to convert mark to grades
    public static String gradeConverter(int mark){

            String grade;
    
            if (mark >= 90) {
                grade = "A**";
            } else if (mark >= 80) {
                grade = "A*";
            } else if (mark >= 70) {
                grade = "A";
            } else if (mark >= 60) {
                grade = "B";
            } else if (mark >= 50) {
                grade = "C";
            } else if (mark >= 40) {
                grade = "D";
            } else {
                grade = "FAIL";
            }
            return grade;
    
        }

}
