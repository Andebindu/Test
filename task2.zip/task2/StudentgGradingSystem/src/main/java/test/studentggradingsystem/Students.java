package test.studentggradingsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author d3742204
 */
import java.util.ArrayList;
import java.util.List;

public class Students {

    //declare students attributes
    private String studentID;
    private String studentFirstName;
    private String studentLastName;
    //declare modules collections
    private List<Modules> studentModules = new ArrayList<>();

    //create a constructor for the students class
    public Students(){
        //instatiate students attributes
        this.studentID = null;
        this.studentFirstName = null;
        this.studentLastName = null;
    } 

    //setter for modules collection
    public void setModule(Modules studentModule) {
        studentModules.add(studentModule);
    }

    //getter for modules collection
    public List<Modules> getStudentModules() {
        return this.studentModules;
    }
    
    //setter for student's first name
    public void setStudentFirstName(String studentFirstName){
        this.studentFirstName = studentFirstName;
    }

    //getter for student's first name
    public String getStudentFirstName(){
        return this.studentFirstName;
    }

    //setter for student's lastt name
    public void setStudentLastName(String studentLastName){
        this.studentLastName = studentLastName;
    }

    //getter for student's last name
    public String getStudentLastName(){
        return this.studentLastName;
    }

    //setter for student's ID
    public void setStudentID(String studentID){
        this.studentID = studentID;
    }

    //getter for student's first name
    public String getStudentID(){
        return this.studentID;
    }
}
