/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test.studentggradingsystem;

/**
 *
 * @author d3742204
 */
import java.util.List;
import java.util.ArrayList;
public class Modules extends Students{

    //declare modules attributes
    public String moduleCode;
    public String moduleName;
    private String moduleTitle;
    private String moduleDescription;
    public String studentGrade;
    public int mark;
    public int highestMark;
    public int lowestMark;
    public double averageMark;
    public long numberofPasses;
    public long numberofFails;
    public List<Integer> moduleMarks;

    //create a constructor for the modules class
    public Modules(){
        //instatiate modules attributes
        this.moduleCode = null;
        this.moduleTitle = null;
        this.moduleDescription = null;
        this.studentGrade = null;
        this.moduleMarks = new ArrayList<>();
    } 

    //setter for module's code
    public void setModuleCode(String moduleCode){
        this.moduleCode = moduleCode;
    }

    //getter for module's code
    public String getModuleCode(){
        return this.moduleCode;
    }

    //setter for module's title
    public void setModuleTitle(String moduleTitle){
        this.moduleTitle = moduleTitle;
    }

    //getter for module's title
    public String getModuleTitle(){
        return this.moduleTitle;
    }

    //setter for module's description
    public void setModuleDescription(String moduleDescription){
        this.moduleDescription = moduleDescription;
    }

    //getter for module's code
    public String getModuleDescription(){
        return this.moduleDescription;
    }

    public String calculateStatistics() {
        highestMark = moduleMarks.stream().mapToInt(Integer::intValue).max().orElse(0);
        lowestMark = moduleMarks.stream().mapToInt(Integer::intValue).min().orElse(0);
        averageMark = moduleMarks.stream().mapToDouble(Integer::doubleValue).average().orElse(0);
        numberofPasses = moduleMarks.stream().filter(mark -> mark >= 40).count();
        numberofFails = moduleMarks.size() - numberofPasses;

        return moduleCode + "," + highestMark + "," + lowestMark + "," + averageMark + "," + numberofPasses + "," + numberofFails;
    }

}
